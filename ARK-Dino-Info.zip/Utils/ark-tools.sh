#!/bin/sh
java -jar ark-tools.jar "$@"