param (
  [string]$Action = $(throw "Action is missing"),
  [string]$SavePath,
  [string]$ExcludeClassesPath = "",
  [double]$BaseLat,
  [double]$BaseLon,
  [string]$MapTemplate,
  [string]$MapsConfigSource
)

<#

Parameters:

$MapTemplate - filename of map template in "Templates" folder

  [string]$XPath,
  [string]$MapName
  [string]$JsonFolder,  
  [string]$XmlPath = $(throw "XML path is missing"),
  [string]$CreaturesType,
  [string]$SavePath,
  [string]$XmlFolderForExcel

TO-DO:

Add templates for all maps:
The Center
Scorched Earth
+Ragnarok

+Fix absolute path to XML files in ARK-Dino-Info.xlsx (\xl\connections.xml)


#>

Set-PSDebug -Strict
#$ErrorActionPreference = "Continue"
$ErrorActionPreference = "Stop"
#$VerbosePreference = 'Continue'

[string]$script_path, [string]$script_dir, [string]$script_name = Get-Item $MyInvocation.MyCommand.Path | % { @($_.FullName, $_.DirectoryName, $_.BaseName) }
$log = Join-Path $script_dir "$script_name.log"
try { Stop-Transcript >$null } catch { }
Start-Transcript -Path $log -Force -Append -EA 0
$script_begin_time = Get-Date

### Folders:
$json_root_folder = Join-Path $script_dir "JSON"
$xml_folder = Join-Path $script_dir "XML"
$utils_folder = Join-Path $script_dir "Utils"
$libs_folder = Join-Path $script_dir "Libs"
$configs_folder = Join-Path $script_dir "Configs"
$map_templates_folder = Join-Path $script_dir "MapTemplates"
$maps_folder = Join-Path $script_dir "Maps"
$temp_folder = Join-Path $script_dir "Temp"
$test_maps_root = Join-Path $script_dir "TestMaps"

### Files:
$config_path = Join-Path $configs_folder "Config.txt"
#$exclude_names_path = Join-Path $configs_folder "ExcludeNames.txt"
$maps_config_txt_path = Join-Path $configs_folder "MapsConfig.txt"
$test_maps_config_path = Join-Path $configs_folder "TestMapsConfig.txt"
$test_maps_xml_path = Join-Path $configs_folder "TestMaps.xml"
$ark_tools_path = Join-Path $utils_folder "ark-tools.exe"
$excel_path = Join-Path $script_dir "ARK-Dino-Info.xlsx"

### Variables:
$script:config = @{ }

### Functions:



<#
  .SYNOPSIS
    A brief description of the Read-TextConfig function.
  
  .DESCRIPTION
    A detailed description of the Read-TextConfig function.
  
  .PARAMETER Path
    A description of the Path parameter.
  
  .NOTES
    Additional information about the function.
#>
function Read-TextConfig {
  [CmdletBinding()]
  [OutputType([hashtable])]
  param
    (
    [Parameter(Mandatory = $true)]
    [string]$Path
  )
  
  #  Write-Host "`r`n*** Function Name:" -ForegroundColor 'White'
  try {
    #  Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    $config = @{ }
    gc $Path -ErrorAction 'Stop' | % { "$_".Trim() } | ? { $_ -and (! $_.StartsWith("#")) } | % { $key = $value = ""; $key, $value = $_ -split "=", 2; $config[$key.Trim()] = $value.Trim() }
    return $config
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
    
  } finally {
  }
  
  #TODO: Place script here
}


function Test-Folder {
  [CmdletBinding()]
  param (
    [Parameter(Mandatory = $true,
               Position = 1)]
    [string]$Path,
    [switch]$Create,
    [switch]$Recreate
  )
  
  #  Write-Host "`r`n*** Function Name:" -ForegroundColor 'White'
  try {
  #  Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    
    if (Test-Path $Path -PathType "Container") {
      return $true
    }
    
    if (!$Create -and !$Recreate) {
      return $false
    }
    
    if ($Recreate) {
      try { Remove-Item -Path $Path -Recurse -Force -Confirm:$false -ErrorAction 'SilentlyContinue' >$null } catch { }
      if (Test-Path $Path -PathType "Container") {
        throw "Cannot delete folder 'Folder' to recreate"
      }
    }
    
    #    Write-Verbose "Create folder '$Path'..."
    New-Item -Path $Path -ItemType Directory -ErrorAction 'SilentlyContinue' >$null
    if (Test-Path $Path -PathType "Container") {
      Write-Verbose "Folder '$Path' is created"
      return $true
    } else {
      throw "Cannot create folder '$Path'"
    }
    
    return $true
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
    
  } finally {
  }
}

function Unpack-ZipFile {
  [CmdletBinding()]
  [OutputType([bool])]
  param (
    [Parameter(Mandatory = $true,
               Position = 1)]
    [string]$ZipPath,
    [Parameter(Mandatory = $true,
               Position = 2)]
    [string]$Destination
  )
    
  try {
    
    Test-Folder -Path $Destination -Create -ErrorAction 'Stop' >$null
    
    $shell = $null
    $shell = New-Object -ComObject "Shell.Application"
    if (!$shell) {
      throw "Can't create object 'Shell.Application'"
    }
    
    #  Write-Host "NameSpace($ZipPath)"
    $zip = $null
    $zip = $shell.NameSpace($ZipPath)
    if (! $zip) {
      throw "Can't get Folder object"
    }
    
    #      $shell = New-Object -ComObject Shell.Application
    #      $ifilter_zip = $shell.Namespace($zip_file_path)
    #      $location = $shell.Namespace($SourceFilesFolder)
    #      $location.Copyhere($ifilter_zip.items())  
    
    #  Write-Host "foreach"
    $dst = $null
    $dst = $shell.Namespace($Destination)
    foreach ($item in $zip.items()) {
      #    Write-Host "Copy item [$item]:"
      #    Write-Host  ($item | fl * -Force | Out-String).Trim()
      #    Write-Host  ($item | gm | Out-String).Trim()
      $dst.copyhere($item.Path, 16 + 4) >$null # 4 - hide progress windows, 16 - overwrite all files
      #    $shell.Namespace($Destination).copyhere($item, 16 + 4) # 4 - hide progress windows, 16 - overwrite all files
    }
    
    #Error:
    #Shell.Application copyhere Could not find this item
    
    return $true
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
  }
}


<#
  .SYNOPSIS
    A brief description of the Create-ZipFile function.
  
  .DESCRIPTION
    A detailed description of the Create-ZipFile function.
  
  .PARAMETER SourceFolder
    A description of the SourceFolder parameter.
  
  .PARAMETER ZipPath
    A description of the ZipPath parameter.
  
  .NOTES
    Additional information about the function.
#>
function Create-ZipFile {
  [CmdletBinding()]
  [OutputType([bool])]
  param
    (
    [Parameter(Mandatory = $true)]
    [string]$SourceFolder,
    [Parameter(Mandatory = $true)]
    [string]$ZipPath
  )
  
  Write-Host "`r`n*** Create ZIP file:" -ForegroundColor 'White'
  try {
#    Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    
    Test-Folder -Path $SourceFolder -ErrorAction 'Stop' >$null
    
    $shell = $null
    $shell = New-Object -ComObject "Shell.Application"
    if (!$shell) {
      throw "Cannot create object 'Shell.Application'"
    }
    
    ### Create new empty ZIP file
    try { Remove-Item -Path $ZipPath -Force -ErrorAction 'SilentlyContinue' >$null } catch { }
    Set-Content -Path $ZipPath -Value ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18)) -ErrorAction 'Stop'    
    Get-Item $ZipPath -ErrorAction 'Stop' | % { $_.IsReadOnly = $false }    
    
    $zip = $null
    $zip = $shell.NameSpace($ZipPath)
    if (! $zip) {
      throw "Cannot create ZIP file '$ZipPath'"
    }
    
    foreach ($item in @(dir $SourceFolder)) {
#      Write-Host "Add '$($item.FullName)': " -NoNewline
      $zip.CopyHere($item.FullName) >$null #, 4 + 6
      # CopyHere is async???
      # bug: 2nd parameter is ignored
      # 4 - hide progress windows, 16 - overwrite all files
      #      Write-Host "OK" -ForegroundColor 'Green'      
      $timeout = 30
      do {
        Start-Sleep -Seconds 1
        $timeout--
        if (! $timeout) { break }
      } until ($zip.Items() | ? { $_.Name -eq $item.Name })
      #      Start-Sleep -Seconds 5
    }
    
    return $true
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
  }
}



<#
  .SYNOPSIS
    A brief description of the Fix-ExcelXmlDataSourcePath function.
  
  .DESCRIPTION
    A detailed description of the Fix-ExcelXmlDataSourcePath function.
  
  .PARAMETER ExcelPath
    A description of the Path parameter.
  
  .PARAMETER NewXmlFolder
    A description of the NewXmlFolder parameter.
  
  .PARAMETER TempFolder
    A description of the TempFolder parameter.
  
  .PARAMETER Path
    A description of the Path parameter.
  
  .NOTES
    Additional information about the function.
#>
function Fix-ExcelXmlDataSourcePath {
  param
    (
    [Parameter(Mandatory = $true)]
    [string]$ExcelPath,
    [Parameter(Mandatory = $true)]
    [string]$NewXmlFolder,
    [string]$TempFolder = $env:TEMP
  )
  
  Write-Host "`r`n*** Fix Excel XML Data Sources Path:" -ForegroundColor 'White'
  $zip_path = $zip_folder = $fixed_zip_path = ""
  try {
#    Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    
    Resolve-Path -LiteralPath $ExcelPath -ErrorAction 'Stop' >$null
#    Resolve-Path -LiteralPath $NewXmlFolder -ErrorAction 'Stop' >$null
    Test-Folder -Path $TempFolder -Create -ErrorAction 'Stop' >$null
    
    ### Unzip file
    $zip_path = Join-Path $TempFolder "Excel_Temp.zip"
    try { Remove-Item -Path $zip_path -Force -ErrorAction 'SilentlyContinue' >$null } catch { }
    Copy-Item -LiteralPath $ExcelPath -Destination $zip_path -Force -ErrorAction 'Stop'
    
    $zip_folder = Join-Path $TempFolder "Excel_Temp"
    Test-Folder -Path $zip_folder -Recreate -ErrorAction 'Stop' >$null
    
    Unpack-ZipFile -ZipPath $zip_path -Destination $zip_folder -ErrorAction 'Stop'
    
    ### Fix url in xl\connections.xml
    $conn_xml_path = Join-Path $zip_folder "xl\connections.xml"
    $xml = New-Object System.Xml.XmlDocument
    $xml.PreserveWhitespace = $true #to keep formatting
    $xml.Load($conn_xml_path) #load from file
    $xml_nsm = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
    $xml_nsm.AddNamespace("ns", "http://schemas.openxmlformats.org/spreadsheetml/2006/main")
    $update_required = $false
    foreach ($node in [System.Xml.XmlElement[]]$xml.SelectNodes("/ns:connections/ns:connection/ns:webPr", $xml_nsm)) {
      #[ends-with(., '.xml')]
      Write-Host "Fix path '$($node.url)': " -NoNewline
      if (! "$($node.url)".EndsWith(".xml")) {
        Write-Host "skip" -ForegroundColor 'Yellow'
        continue
      }
      $xml_file_name = ""
      $xml_file_name = [System.IO.Path]::GetFileName($node.url)
      $new_xml_path = Join-Path $NewXmlFolder $xml_file_name
      if ($new_xml_path -ne $node.url) {
        $node.SetAttribute("url", $new_xml_path)
        $update_required = $true
        Write-Host "updated" -ForegroundColor 'Magenta'
      } else {
        Write-Host "not required" -ForegroundColor 'Green'
      }
    }
    
    if ($update_required) {
      $xml.Save($conn_xml_path)
      Write-Host "Connections were updated" -ForegroundColor 'Magenta'
      
      ### Archive folder to zip
      $fixed_zip_path = Join-Path $TempFolder "Excel_Temp_Fixed.zip"
      try { Remove-Item -Path $fixed_zip_path -Force -ErrorAction 'SilentlyContinue' >$null } catch { }
      Create-ZipFile -SourceFolder $zip_folder -ZipPath $fixed_zip_path -ErrorAction 'Stop' >$null
      
      ### Replace original excel
      try { Remove-Item -Path $ExcelPath -Force -ErrorAction 'SilentlyContinue' >$null } catch { }
      Copy-Item -LiteralPath $fixed_zip_path -Destination $ExcelPath -Force -ErrorAction 'Stop'
      
    } else {
      Write-Host "Update not required" -ForegroundColor 'Green'
    }
    
    return $true
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
    
  } finally {    
    try { Remove-Item -Path $zip_path -Force -ErrorAction 'SilentlyContinue' >$null } catch { }
    try { Remove-Item -Path $zip_folder -Recurse -Force -Confirm:$false -ErrorAction 'SilentlyContinue' >$null } catch { }    
    try { Remove-Item -Path $fixed_zip_path -Force -ErrorAction 'SilentlyContinue' >$null } catch { }    
  }
}


<#
  .SYNOPSIS
    A brief description of the Get-Angle function.
  
  .DESCRIPTION
    A detailed description of the Get-Angle function.
  
  .PARAMETER X1
    A description of the X1 parameter.
  
  .PARAMETER Y1
    A description of the Y1 parameter.
  
  .NOTES
    Additional information about the function.
#>
function Get-Angle {
  param
    (
    [Parameter(Mandatory = $true)]
    [double]$X1,
    [Parameter(Mandatory = $true)]
    [double]$Y1,
    [Parameter(Mandatory = $true)]
    [double]$X2,
    [Parameter(Mandatory = $true)]
    [double]$Y2
  )
  
  [double]$angle = 0
  $angle = [Math]::Atan2($Y1 - $Y2, $X1 - $X2) / [Math]::PI * 180
  if ($angle -lt 0) { $angle += 360.0 } #��� ����� �������� �� 0...180 � -1...-180
  return $angle
}

function Get-Direction {
  param
    (
    [Parameter(Mandatory = $true)]
    [double]$Angle
  )
  
  [string[]]$caridnals = @("W", "N-W", "N", "N-E", "E", "S-E", "S", "S-W", "W")
  #  [string[]]$caridnals = @("N", "N-E", "E", "S-E", "S", "S-W", "W", "N-W", "N")
  return $caridnals[[int][Math]::Round(($Angle % 360.0) / 45.0)]
}



<#
  .SYNOPSIS
    A brief description of the Convert-JsonToXml function.
  
  .DESCRIPTION
    A detailed description of the Convert-JsonToXml function.
  
  .PARAMETER JsonFolder
    A description of the Folder parameter.
  
  .PARAMETER ResultXmlPath
    A description of the ResultPath parameter.
  
  .PARAMETER ExcludeClassesPath
    A description of the ExcludeClassesPath parameter.
  
  .PARAMETER BaseLat
    A description of the BaseLat parameter.
  
  .PARAMETER BaseLon
    A description of the BaseLon parameter.
  
  .PARAMETER Folder
    A description of the Folder parameter.
  
  .PARAMETER ResultPath
    A description of the ResultPath parameter.
  
  .NOTES
    Additional information about the function.
#>
function Convert-JsonToXml {
  [CmdletBinding()]
  param
    (
    [Parameter(Mandatory = $true)]
    [string]$JsonFolder,
    [Parameter(Mandatory = $true)]
    [string]$ResultXmlPath,
    [string]$ExcludeClassesPath = "",
    [double]$BaseLat,
    [double]$BaseLon
  )
  
  Write-Host "`r`n*** Convert-JsonToXml:" -ForegroundColor 'White'
  try {
#    Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'

    Test-Folder -Path $xml_folder -Create -ErrorAction 'Stop' >$null    
    try { Remove-Item -Path $ResultXmlPath -Force -ErrorAction 'SilentlyContinue' >$null } catch { }
    
    $files = @()
    $files = @(dir $JsonFolder -Include "*.json" -Recurse | ? { $_.Name -ne "classes.json" } | sort Name)
    if (! $files) {
      Write-Host "No JSON-files in ''" -ForegroundColor 'Yellow'
      return $false
    }
    
    $exclude_classes = @()
    if ($ExcludeClassesPath) {
      $exclude_classes = @(gc $ExcludeClassesPath -ErrorAction 'Stop' | % { "$_".Trim() } | ? { $_ -and (! $_.StartsWith("#")) })
    }
    
    $result_xml = [xml]'<?xml version="1.0" encoding="UTF-8"?><Items/>'
    
    $cnt = 0
    $total = $files.Length
    Write-Host "Process [$total] files..."
    :file foreach ($file in $files) {
      $cnt++
#      Write-Host "Process file [$cnt/$total] '$($file.Name)': " -NoNewline
      $json = ""
      $json = [System.IO.File]::ReadAllText($file.FullName)
      if (! $json) {
        Write-Host "cannot read file" -ForegroundColor 'Red'
        continue
      }
      
      $xml = $null
      #      $xml = [Newtonsoft.Json.JsonConvert]::DeserializeXmlNode($json)
      $xml = [Newtonsoft.Json.JsonConvert]::DeserializeXmlNode('{"Item":' + $json + "}", "Items")
      
      foreach ($node in [System.Xml.XmlElement[]]$xml.SelectNodes("/Items/Item")) {
        
        $class = ""
        $class = $file.BaseName
        
        ### Skip exclusions
        if ($exclude_classes -contains $class) {
#          Write-Host "skip" -ForegroundColor 'Yellow'
          continue file
        }
        
        #        $node.SetAttribute("Class", $file.BaseName)
        $node.AppendChild($xml.CreateElement("Class")).InnerText = $class
        
        [double]$lat = [double]$lon = 0.0
        $lat = [double]$node.location.lat
        $lon = [double]$node.location.lon
        
        ### Add rounded lat and lon
        $node.AppendChild($xml.CreateElement("Lat")).InnerText = ("{0:f1}" -f $lat).Replace(",", ".")
        $node.AppendChild($xml.CreateElement("Lon")).InnerText = ("{0:f1}" -f $lon).Replace(",", ".")
        
        if (($BaseLat + $BaseLon) -gt 0) {
          
          ### Add distance
          [double]$distance = 0.0
          $distance = [Math]::Sqrt([Math]::Pow($lat - $BaseLat, 2) + [Math]::Pow($lon - $BaseLon, 2))
          $node.AppendChild($xml.CreateElement("Distance")).InnerText = ("{0:f1}" -f $distance).Replace(",", ".")
          
          ### Add direction
          [double]$angle = 0.0
          [double]$angle = Get-Angle -X1 $BaseLon -Y1 $BaseLat -X2 $lon -Y2 $lat
          $node.AppendChild($xml.CreateElement("Angle")).InnerText = ("{0:f1}" -f $angle).Replace(",", ".")
          $node.AppendChild($xml.CreateElement("Direction")).InnerText = Get-Direction $angle
        }
        
        ### Add to result XML
        $result_xml.DocumentElement.AppendChild($result_xml.ImportNode($node, $true)) >$null
      }
      
#      Write-Host "OK" -ForegroundColor 'Green'
    }
    
    ### Find max level for every class
    Write-Host "Find max level for every class: " -NoNewline
    $max_levels = @{ }
    foreach ($node in [System.Xml.XmlElement[]]$result_xml.SelectNodes("/Items/Item")) {
      $level = [int]$node.baseLevel
      if ($max_levels.ContainsKey($node.type)) {
        if (($level -gt $max_levels[$node.type])) {
          $max_levels[$node.type] = $level
        }
      } else {
        $max_levels[$node.type] = $level
      }
    }
    
    ### Set max level for every class
    foreach ($max_level in $max_levels.GetEnumerator()) {
      foreach ($node in [System.Xml.XmlElement[]]$result_xml.SelectNodes("/Items/Item[type='$($max_level.Key)'][baseLevel='$($max_level.Value)']")) {
        $node.SetAttribute("MaxLevel", "true")
      }
    }
    Write-Host "OK" -ForegroundColor 'Green'
    
    Write-Host "Save result to '$ResultXmlPath': " -NoNewline
    $result_xml.Save($ResultXmlPath)
    Write-Host "OK" -ForegroundColor 'Green'
    
    return $true
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
    
  } finally {
  }
}



<#
  .SYNOPSIS
    A brief description of the Export-CreaturesFromSaveToJson function.
  
  .DESCRIPTION
    A detailed description of the Export-CreaturesFromSaveToJson function.
  
  .PARAMETER SavePath
    A description of the SavePath parameter.
  
  .PARAMETER CreaturesType
    A description of the CreaturesType parameter.
  
  .NOTES
    Additional information about the function.
#>
function Export-CreaturesFromSaveToJson {
  [CmdletBinding()]
  param
    (
    [Parameter(Mandatory = $true)]
    [string]$SavePath,
    [Parameter(Mandatory = $true)]
    [ValidateSet("tamed", "wild", IgnoreCase = $true)]
    [string]$CreaturesType
  )
  
  Write-Host "`r`n*** Export $CreaturesType creatures: " -ForegroundColor 'White' -NoNewline
  try {
    #  Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    
    $SavePath = (Resolve-Path $SavePath -ErrorAction 'Stop').Path
    
    $json_folder = Join-Path $json_root_folder $CreaturesType
    
    if (Test-Path $json_folder -PathType "Container") {
      try { Remove-Item -Path "$json_folder\*.json" -Force -ErrorAction 'SilentlyContinue' >$null } catch { }
    } else {
      Test-Folder -Path $json_folder -Create -ErrorAction 'Stop' >$null
    }
    
    Push-Location $utils_folder
    & $ark_tools_path $CreaturesType.ToLower() $SavePath $json_folder
    if ($?) { Write-Host "OK" -ForegroundColor 'Green' } else { Write-Host "ERROR" -ForegroundColor 'Red' }
    Pop-Location
    
    return $true
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
    
  } finally {
  }
}

function Read-ExcelSheet1 {
  [CmdletBinding()]
  param
    (
    [Parameter(Mandatory = $true)]
    [string]$Path,
    [string]$Sheet
  )
  
  #  Write-Host "`r`n*** Function Name:" -ForegroundColor 'White'
  $connection = $recordset = $null
  $connection_opened = $false
  try {
    #  Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    
    # Need to install:
    # https://www.microsoft.com/en-us/download/confirmation.aspx?id=13255
    
    $connection = New-Object -ComObject "ADODB.Connection"
    #    $objRecordSet = New-Object -com "ADODB.Recordset"
    
    $conn_str = 'Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties="Excel 12.0 Xml;HDR=YES";' -f $Path    
#    $conn_str = 'Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties="Excel 12.0 Xml;HDR=YES;IMEX=1";' -f $Path
    #    $connection.Open("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=$($Path);Extended Properties=Excel 12.0;")
    
    $adModeRead = 1
    $connection.Mode = $adModeRead
    $connection.Open($conn_str)
    
    #    $objConnection.Open("Provider = Microsoft.Jet.OLEDB.4.0; Data Source = C:\Scripts\Test.mdb")    
    #    $objRecordset.Open("Select * From Computers", $objConnection, $adOpenStatic, $adLockOptimistic)
    
    $connection_opened = $true
    
    $sql = "Select * from [$($Sheet)`$]"
    $recordset = $connection.Execute($sql)
    
    #    Write-Host ($recordset | fl * | Out-String).Trim()
    
    $fields = @($recordset.Fields | select -ExpandProperty Name)
    [hashtable]$prop_names = @{ }
    $fields | % { $prop_name = ""; $prop_name = $_ -replace "\s", "_"; $prop_names[$_] = $prop_name }
    
    $items = @()
    
    $recordset.MoveFirst()
    do {
      ### Init item properties
      $item_props = @{ }
      $prop_names.Values | % { $item_props[$_] = "" }
      
      foreach ($field in $fields) {
        $value = ""
        $value = [string]($recordset.Fields.Item($field).Value)
        $item_props[$prop_names[$field]] = $value
      }
      
      $items += New-Object "PSCustomObject" -Property $item_props
      #      Write-Host $recordset.Fields.Item("MapName").Value
      $recordset.MoveNext()
    } until ($recordset.EOF)
    
    
    #    do {
    #      Write-Host "EXEC sp_InsertVendors '" $ExcelRecordSet.Fields.Item("Vendor Code").Value "'"
    #      $ExcelRecordSet.MoveNext()
    #    } Until ($ExcelRecordSet.EOF)
    
    
    return $items
#    return @(, $items)
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
    
  } finally {
    if ($recordset) {
      $recordset.Close()
    }
    if ($connection -and $connection_opened) { 
      $connection.Close()
    }
  }
  
}

function Read-ExcelSheet2 {
  [CmdletBinding()]
  param
    (
    [Parameter(Mandatory = $true)]
    [string]$Path,
    [string]$SheetName
  )
  
  ### Supported only 26 columns A-Z - need to fix
  # https://hinchley.net/articles/read-a-microsoft-excel-workbook-using-powershell-and-the-open-xml-sdk/
  
  #  Write-Host "`r`n*** Function Name:" -ForegroundColor 'White'
  $doc = $null
  try {
    #  Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    #    [Reflection.Assembly]::LoadFrom("D:\Work\Others\Home\ARK\ARK-Dino-Info\_Test\DocumentFormat.OpenXml.dll") >$null
    
    $doc = [DocumentFormat.OpenXml.Packaging.SpreadsheetDocument]::Open($Path, $false)
    
    #[DocumentFormat.OpenXml.Spreadsheet.Sheet]
    $sheet = $null
    $sheet = $doc.WorkbookPart.Workbook.Sheets | select * | ? { $_.Name -like "$($SheetName)*" } ### select * - �����!!! ����� �� ����� ��������
    if (! $sheet) {
      throw "Cannot get sheet '$SheetName'"
    }
    
    [DocumentFormat.OpenXml.Packaging.WorksheetPart]$wsp = $null
    [DocumentFormat.OpenXml.Packaging.WorksheetPart]$wsp = $doc.WorkbookPart.GetPartById($sheet.Id)
    if (! $wsp) {
      throw "Cannot get WorkbookPart with ID '$($sheet.Id)'"
    }
    
    #    [DocumentFormat.OpenXml.Packaging.SharedStringTablePart]
    $string_table_part = $cells_values = $null
    $string_table_part = $doc.WorkbookPart.SharedStringTablePart
    $cells_values = $string_table_part.SharedStringTable.Elements()
    
    $ws_childs = $wsp.Worksheet.Descendants()
#    $ws_childs | fl * -Force >".\all_childs.txt" ### for debug
    
#    Write-Host "`r`n*** Get field names:"
    $fields = @()
    [DocumentFormat.OpenXml.Spreadsheet.Row]$row1 = $null
    [DocumentFormat.OpenXml.Spreadsheet.Row]$row1 = $ws_childs | ? { ($_.LocalName -eq "row") -and ($_.RowIndex.Value -eq 1) } | select -First 1
    
    foreach ($cell in $row1.ChildElements) {
      $value = ""
      if ($cell.DataType.Value -eq "SharedString") {
        $value = $cells_values[$cell.InnerText].InnerText
      } else {
        $value = $cell.InnerText
      }
      $fields += $value
    }
#    Write-Host "`r`n*** Fields: [$($fields -join ';')]"
    [hashtable]$prop_names = @{ }
    $fields | % { $prop_name = ""; $prop_name = $_ -replace "\s", "_"; $prop_names[$_] = $prop_name }
    
    ###
    #    $ws_childs | ? { $_.LocalName -eq "c" } | % { $_ | fl * -Force } >>".\all_cells.txt"
    
    $items = @()
    $cnt = 0
    foreach ($row in @($ws_childs | ? { ($_.LocalName -eq "row") -and ($_.RowIndex.Value -ne 1) })) {
      $cnt++
      #      Write-Host "Process data row [$cnt]: [" -NoNewline
      #      ,$row.ChildElements | Out-String >".\row_$($cnt).txt"
      #      $column = 0
      $item_props = @{ }
      $prop_names.Values | % { $item_props[$_] = "" } # init
      
      foreach ($cell in $row.ChildElements) {
        $column = [int][char]($cell.CellReference -replace "\d", "") - 64
        $value = ""
        if ($cell.DataType.Value -eq "SharedString") {
          $value = $cells_values[$cell.InnerText].InnerText
        } else {
          $value = $cell.InnerText
        }
        #        Write-Host "$($column):$($value); " -NoNewline
        
        $item_props[$prop_names[$fields[$column - 1]]] = $value
      }
      #      Write-Host "]"
      $items += New-Object "PSCustomObject" -Property $item_props
    }
    
    return $items
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
    
  } finally {
    if ($doc) {
      try { $doc.Close() } catch { }
    }
  }
}


function Get-ImageEncoder([System.Drawing.Imaging.ImageFormat]$Format) {
  return ([System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | ? { $_.FormatID -eq $Format.Guid })
}


<#
  .SYNOPSIS
    A brief description of the Save-BitmapAsJpeg function.
  
  .DESCRIPTION
    A detailed description of the Save-BitmapAsJpeg function.
  
  .PARAMETER Bitmap
    A description of the Bitmap parameter.
  
  .PARAMETER Path
    A description of the Path parameter.
  
  .PARAMETER Quality
    A description of the Quality parameter.
  
  .NOTES
    Additional information about the function.
#>
function Save-BitmapAsJpeg {
  [CmdletBinding()]
  param
    (
    [Parameter(Mandatory = $true)]
    [System.Drawing.Bitmap]$Bitmap,
    [Parameter(Mandatory = $true)]
    [string]$Path,
    [ValidateRange(0, 100)]
    [long]$Quality = 90
  )
  
  #  Write-Host "`r`n*** Function Name:" -ForegroundColor 'White'
  try {
    #  Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'    
    $format = [System.Drawing.Imaging.ImageFormat]::Jpeg
    $jpeg_encoder = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | ? { $_.FormatID -eq $format.Guid }
    $encoder = [System.Drawing.Imaging.Encoder]::Quality
    $encoder_parameters = New-Object "System.Drawing.Imaging.EncoderParameters" -ArgumentList 1
    $encoder_parameter = New-Object "System.Drawing.Imaging.EncoderParameter" -ArgumentList @($encoder, $Quality)
    $encoder_parameters.Param[0] = $encoder_parameter
    $Bitmap.Save($Path, $jpeg_encoder, $encoder_parameters)
    return $true
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
    
  } finally {
  }
}

<#
  .SYNOPSIS
    A brief description of the Create-Map function.
  
  .DESCRIPTION
    A detailed description of the Create-Map function.
  
  .PARAMETER TemplatePath
    A description of the TemplatePath parameter.
  
  .PARAMETER ResultPath
    A description of the ResultPath parameter.
  
  .PARAMETER Points
    A description of the Points parameter.
  
  .PARAMETER Color
    A description of the Color parameter.
  
  .NOTES
    Additional information about the function.
#>
function Create-Map {
  [CmdletBinding()]
  param
    (
    [Parameter(Mandatory = $true)]
    [hashtable]$MapTemplate,
    [Parameter(Mandatory = $true)]
    [string]$ResultFolder,
    [Parameter(Mandatory = $true)]
    [string]$MapName,
    [Parameter(Mandatory = $true)]
    [string]$XmlPath,
    [Parameter(Mandatory = $true)]
    [string]$XPath,
    [switch]$PrintLocation,
    [switch]$PrintType,
    [switch]$PrintLevel
  )
  
  Write-Host "`r`n*** Create-Map '$MapName':" -ForegroundColor 'White'
  $pen = $brush = $null
  
  try {
    #    Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    
    $xml = New-Object System.Xml.XmlDocument
    #  $xml.PreserveWhitespace = $true #to keep formatting
    $xml.Load($XmlPath) #load from file
    $nodes = $xml.SelectNodes("//Item$($XPath)")
    if (!$nodes.Count) {
      Write-Host "Items not found" -ForegroundColor 'Yellow'
      return $false
    }
    Write-Host "Found [$($nodes.Count)] items. Create map..."
    #    Write-Host "Found [$($nodes.Count)] items by XPath '$XPath'. Create map..."
    
    #    return
    
    #    Write-Host "Read map template '$($MapTemplate.Path)': " -NoNewline
    $bitmap = $null
    $bitmap = New-Object "System.Drawing.Bitmap" -ArgumentList $MapTemplate.Path
    if (!$bitmap) {
      throw "Cannot read map template '$($MapTemplate.Path)'"
    }
    #    Write-Host "OK" -ForegroundColor 'Green'
    
    $graphics = $null
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    if (!$graphics) {
      throw "Cannot create graphics object"
    }
    
    
    #    $graphics.DrawRectangle($pen, 10, 20, 100, 200)    
    $mark_size = 10
    $font_size = $mark_size * 1.4
    $male_color = [System.Drawing.Color]::Cyan
    $female_color = [System.Drawing.Color]::Magenta
    
    [double]$add_x = [double]$MapTemplate.Left - ([double]$mark_size / 2.0)
    [double]$add_y = [double]$MapTemplate.Top - ([double]$mark_size / 2.0)
    [double]$mult_x = ([double]$MapTemplate.Right - [double]$MapTemplate.Left) / [double]$MapTemplate.UnitsX
    [double]$mult_y = ([double]$MapTemplate.Bottom - [double]$MapTemplate.Top) / [double]$MapTemplate.UnitsY
    
    $pen = New-Object "System.Drawing.Pen" -ArgumentList "Black", 2
    $brush_male = New-Object "System.Drawing.SolidBrush" -ArgumentList $male_color
    $brush_female = New-Object "System.Drawing.SolidBrush" -ArgumentList $female_color
    $font = New-Object "System.Drawing.Font" -ArgumentList "Monospace", 30, "Bold", "Pixel"
    #($mark_size * 1.5)
    #$pen.Width = 8.0
    #$pen.LineJoin = System.Drawing.Drawing2D.LineJoin.Bevel    
    
    foreach ($node in $nodes) {
      $level = ""
      [double]$lat = [double]$lon = 0.0
      $gender = $null
      $brush = $null
      [double]$mark_x = 0.0
      [double]$mark_y = 0.0
      
      #$point.X - lat = Y
      #$point.Y - lon = X
      [double]$lat = $node.location.lat
      [double]$lon = $node.location.lon
      if ($node.female -eq "true") {
        $gender = "F"
        $brush = $brush_female
      } else {
        $gender = "M"
        $brush = $brush_male
      }
      $level = $node.baseLevel
      
      [int]$mark_x = [Math]::Round($add_x + ($lon * $mult_x))
      [int]$mark_y = [Math]::Round($add_y + ($lat * $mult_y))
      
      #      Write-Host "Add mark [lat:$lat, lon:$lon] -> [$mark_x,$mark_y]" -ForegroundColor 'Cyan'
      $graphics.DrawEllipse($pen, $mark_x, $mark_y, $mark_size, $mark_size)
      $graphics.FillEllipse($brush, $mark_x, $mark_y, $mark_size, $mark_size)
      
      #      continue
      
      $text = ""
      
      if ($PrintType) {
        $text += $node.type + "`r`n"
      }
      
      if ($PrintLevel) {
        $text += "L" + $node.baseLevel + "`r`n"
      }
      
      if ($PrintLocation) {
        $text += ("{0:f1}/{1:f1}" -f $lat, $lon).Replace(",", ".")
      }
      
      if ($text) {
        #      // assuming g is the Graphics object on which you want to draw the text
        $graphics_path = New-Object "System.Drawing.Drawing2D.GraphicsPath"
        $string_format = New-Object System.Drawing.StringFormat
        $string_format.Alignment = 'Center' # .Alignment = StringAlignment.Center
        $graphics_path.AddString($text, ([System.Drawing.FontFamily]::Families | ? { $_.Name -eq "Arial" }), [System.Drawing.FontStyle]::Bold, ($graphics.DpiY * $font_size) / 72, (New-Object System.Drawing.Point ($mark_x, ($mark_y + $mark_size))), $string_format)
        #Impact
        #      $graphics_path.AddString($text, [System.Drawing.FontFamily]::, [System.Drawing.FontStyle]::Bold, ($graphics.DpiY * $font_size) / 72, (New-Object System.Drawing.Point ($mark_x, ($mark_y + $mark_size))), $string_format)
        
        $graphics.DrawPath($pen, $graphics_path)
        $graphics.FillPath($brush, $graphics_path)
        
        #      $graphics.DrawString($text, $font, $brush, $mark_x, $mark_y + $mark_size)
        #      $graphics.DrawRectangle($pen, $mark_x, $mark_y, $mark_size, $mark_size)        
      }
      
      #      [System.Drawing.FontFamily]::Families
      
      #      $text = "TEST"      
      
    }
    
    #    $result_path = Join-Path $ResultFolder ($MapName + [System.IO.Path]::GetExtension($MapTemplate.Path))
    $result_path = Join-Path $ResultFolder ($MapName + ".jpg")
    Write-Host "Save map '$MapName' to '$result_path': " -NoNewline
    Save-BitmapAsJpeg -Bitmap $bitmap -Path $result_path -ErrorAction 'Stop' >$null
    #    $bitmap.Save($result_path)
    # https://msdn.microsoft.com/en-us/library/ytz20d80(v=vs.80).aspx
#    $bitmap.Save($result_path, [System.Drawing.Imaging.ImageFormat]::Png)
    #    $bitmap.Save($result_path, [System.Drawing.Imaging.ImageFormat]::Jpeg)
    Write-Host "OK" -ForegroundColor 'Green'
    
    return $true
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
    
  } finally {
    if ($pen) { $pen.Dispose() }
    if ($brush) { $brush.Dispose() }
  }
}








<#
  .SYNOPSIS
    A brief description of the Create-Maps function.
  
  .DESCRIPTION
    A detailed description of the Create-Maps function.
  
  .PARAMETER XmlPath
    A description of the XmlPath parameter.
  
  .PARAMETER MapTemplate
    A description of the MapTemplate parameter.
  
  .PARAMETER ResultFolder
    A description of the MapsFolder parameter.
  
  .PARAMETER MapsConfigPath
    A description of the ConfigPath parameter.
  
  .PARAMETER MapsConfig
    A description of the MapsConfig parameter.
  
  .PARAMETER Template
    A description of the MapTemplate parameter.
  
  .PARAMETER ConfigPath
    A description of the ConfigPath parameter.
  
  .PARAMETER DestinationFolder
    A description of the MapsFolder parameter.
  
  .PARAMETER Folder
    A description of the MapsFolder parameter.
  
  .PARAMETER MapsFolder
    A description of the MapsFolder parameter.
  
  .NOTES
    Additional information about the function.
#>
function Create-Maps {
  [CmdletBinding()]
  param
    (
    [Parameter(Mandatory = $true)]
    [string]$XmlPath,
    [Parameter(Mandatory = $true)]
    [string]$MapTemplate,
    [Parameter(Mandatory = $true)]
    [string]$ResultFolder,
    [string]$MapsConfigPath,
    $MapsConfig
  )
  
  #  Write-Host "`r`n*** Function Name:" -ForegroundColor 'White'
  try {
    #  Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    
    Test-Folder -Path $maps_folder -Create -ErrorAction 'Stop'
    
    try { Remove-Item -Path "$maps_folder\*" -Force -ErrorAction 'SilentlyContinue' >$null } catch { }
    
    $map_template_path = Join-Path $map_templates_folder $MapTemplate
    Copy-Item -LiteralPath $map_template_path -Destination (Join-Path $ResultFolder ("__MapTemplate" + [System.IO.Path]::GetExtension($map_template_path))) -Force -ErrorAction 'SilentlyContinue' >$null
    
    $map_template_config = @{ }
    $map_template_config = gc "$map_template_path.txt" -ErrorAction 'Stop' | Out-String | ConvertFrom-StringData -ErrorAction 'Stop'
    $map_template_config.Path = $map_template_path
    
    if ($MapsConfigPath) {
      $MapsConfig = @(Import-Csv -Path $MapsConfigPath -Delimiter "`t" -ErrorAction 'Stop')
    } elseif (! $MapsConfig) {
      throw "Masps config not specified"
    }
    
    foreach ($map in $MapsConfig) {
#      Write-Host "Create map '$($map.MapName)':"
      
      if ("$($map.MapName)".StartsWith("#")) {
        continue
      }
      
      $xpath = ""
      
      if ($map.CreatureType) {
        
        $xpath = ""
        foreach ($str in [string[]]@("$($map.CreatureType)".Split(",", [StringSplitOptions]::RemoveEmptyEntries) | % { $_.Trim() } | ? { $_ })) {
          #            [string]$str = $map.CreatureType
          if ($xpath) { $xpath += " or " }
          if ($str.EndsWith("*")) {
            $str = $str.Substring(0, $str.Length - 1)
            $xpath += "starts-with(type,'$str')"
          } else {
            $xpath += "type='$($str)'"
          }
        }
        $xpath = "[$xpath]"
      }
      
      if ($map.CreatureClass) {
        $xpath = ""
        foreach ($str in [string[]]@("$($map.CreatureClass)".Split(",", [StringSplitOptions]::RemoveEmptyEntries) | % { $_.Trim() } | ? { $_ })) {
          if ($xpath) { $xpath += " or " }
          $xpath += "Class='$($str)'"
        }
        $xpath = "[$xpath]"
      }
      
      if ($map.MinLevel) {
        $xpath += "[baseLevel>=$($map.MinLevel)]"
      }
      
      if ($map.MaxLevel) {
        if ($map.MaxLevel -eq "yes") {
          $xpath += "[@MaxLevel='true']"
        } else {
          $xpath += "[baseLevel<=$($map.MaxLevel)]"
        }
      }
      
      if ($map.Gender) {
        if ($map.Gender -eq "female") {
          $xpath += "[female='true']"
        } else {
          $xpath += "[female='false' or count(female)=0]"
        }
      }
      
      #        Write-Host "XPath: '$xpath'" -ForegroundColor 'Cyan'
      #        continue
      
      Create-Map -XmlPath $XmlPath -XPath $xpath -MapTemplate $map_template_config -ResultFolder $ResultFolder -MapName $map.MapName -PrintType:($map.PrintType -eq "yes") -PrintLocation:($map.PrintLocation -eq "yes") -PrintLevel:($map.PrintLevel -eq "yes") >$null
    }
    
    return $true
    
  } catch {
    if ($ErrorActionPreference -eq 'Stop') {
      throw
    } elseif ($ErrorActionPreference -ne 'SilentlyContinue') {
      Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
      Write-Host ("Parameters:`r`n" + (New-Object "PSObject" -Property $PSBoundParameters | fl * | Out-String).Trim()) -ForegroundColor 'Cyan'
    }
    return $false
    
  } finally {
  }
}


### Main:

# For IDE:
if (0) {
  Add-Type -Path "D:\Work\Others\Home\ARK\ARK-Dino-Info\Libs\Newtonsoft.Json.dll"
  Add-Type -Path "D:\Work\Others\Home\ARK\ARK-Dino-Info\Libs\DocumentFormat.OpenXml.dll"
}
#Import-Module ModuleName -Global -ErrorAction 'Stop'

try {
  [Reflection.Assembly]::LoadFrom((Join-Path $libs_folder "Newtonsoft.Json.dll")) >$null
  [Reflection.Assembly]::LoadFrom((Join-Path $libs_folder "DocumentFormat.OpenXml.dll")) >$null
  [Reflection.Assembly]::LoadWithPartialName("System.Drawing") >$null
  
#  Write-Host "Read config: " -NoNewline
  $script:config = @{ }
  $script:config = Read-TextConfig -Path $config_path -ErrorAction 'Stop'
#  $script:config = gc $config_path -ErrorAction 'Stop' | Out-String | ConvertFrom-StringData -ErrorAction 'Stop'
#  Write-Host "OK" -ForegroundColor 'Green'
  
  if (! $SavePath) { $SavePath = $script:config.SavePath }
  if (! $BaseLat) { $BaseLat = $script:config.BaseLat }
  if (! $BaseLon) { $BaseLon = $script:config.BaseLon }  
  if (! $MapTemplate) { $MapTemplate = $script:config.MapTemplate }
  if (! $MapsConfigSource) { $MapsConfigSource = $script:config.MapsConfigSource }
#  if (! $XmlFolderForExcel) { $XmlFolderForExcel = $script:config.XmlFolderForExcel }  
  
  Write-Host "Run action '$Action':" -ForegroundColor 'Magenta'
  switch ($Action) {
    
    "ExportTamedCreatures" {
      Export-CreaturesFromSaveToJson -SavePath $SavePath -CreaturesType "Tamed" >$null
      break
    }
    
    "ExportWildCreatures" {
      Export-CreaturesFromSaveToJson -SavePath $SavePath -CreaturesType "Wild" >$null
      break
    }
    
    "ExportAllCreatures" {
      Export-CreaturesFromSaveToJson -SavePath $SavePath -CreaturesType "Tamed" >$null
      Export-CreaturesFromSaveToJson -SavePath $SavePath -CreaturesType "Wild" >$null
      break
    }
    
    "CreateTamedXml" {
      Convert-JsonToXml -JsonFolder (Join-Path $json_root_folder "Tamed") -ResultXmlPath (Join-Path $xml_folder "Tamed.xml") -BaseLat $BaseLat -BaseLon $BaseLon -ExcludeClassesPath $ExcludeClassesPath >$null
      break
    }
    
    "CreateWildXml" {
      Convert-JsonToXml -JsonFolder (Join-Path $json_root_folder "Wild") -ResultXmlPath (Join-Path $xml_folder "Wild.xml") -BaseLat $BaseLat -BaseLon $BaseLon -ExcludeClassesPath $ExcludeClassesPath >$null
      break
    }
    
    "FixExcel" {
      Fix-ExcelXmlDataSourcePath -ExcelPath $excel_path -NewXmlFolder $xml_folder -TempFolder $temp_folder >$null
      break
    }
    
    "CreateWildMaps" {      
      $maps_config = @()      
      if ($MapsConfigSource -eq "txt") {
        $maps_config = @(Import-Csv -Path $maps_config_txt_path -Delimiter "`t" -ErrorAction 'Stop')
      } elseif ($MapsConfigSource -eq "excel") {
        Write-Host "Read maps config from '$excel_path': " -NoNewline
        ### Copy Excel to temp folder to avoid error if file is opened
        Test-Folder -Path $temp_folder -Create -ErrorAction 'Stop' >$null
        $temp_excel_path = Join-Path $temp_folder "Excel_Temp.xlsx"
        try { Remove-Item -Path $temp_excel_path -Force -ErrorAction 'SilentlyContinue' >$null } catch { }
        Copy-Item -LiteralPath $excel_path -Destination $temp_excel_path -Force -ErrorAction 'Stop'
        $maps_config = @(Read-ExcelSheet2 -Path $temp_excel_path -Sheet "Maps Config" -ErrorAction 'Stop')
        try { Remove-Item -Path $temp_excel_path -Force -ErrorAction 'SilentlyContinue' >$null } catch { }
        #        Write-Host ($maps_config | Out-String).Trim()
#        $maps_config = @(Read-ExcelSheet1 -Path $excel_path -Sheet "Maps Config" -ErrorAction 'Stop')
        Write-Host "OK" -ForegroundColor 'Green'
      } else {
        throw "Unknown maps config source '$MapsConfigSource'"
      }
      
      ### For debug
#      Test-Folder -Path (Join-Path $script_dir "_Test") -Create -ErrorAction 'SilentlyContinue' >$null    
#      $maps_config | fl * -Force | Out-File (Join-Path $script_dir "_Test\maps_config_test.txt") -Encoding "UTF8" -Force -ErrorAction 'SilentlyContinue'
      
      Create-Maps -XmlPath (Join-Path $xml_folder "Wild.xml") -MapTemplate $MapTemplate -MapsConfig $maps_config -ResultFolder $maps_folder >$null
      break
    }
    
    "CreateTestMaps" {
      $maps_config = @()
      $maps_config = @(Import-Csv -Path $test_maps_config_path -Delimiter "`t" -ErrorAction 'Stop')      
      $test_maps_folder = Join-Path $test_maps_root ([System.IO.Path]::GetFileNameWithoutExtension($MapTemplate))
      Test-Folder -Path $test_maps_folder -Create -ErrorAction 'Stop'
      Create-Maps -XmlPath $test_maps_xml_path -MapTemplate $MapTemplate -MapsConfig $maps_config -ResultFolder $test_maps_folder >$null
      break      
    }
    
    default {
      throw "Unknown action 'Action'"
    }
  }
  
  Write-Host "Action '$Action' finished" -ForegroundColor 'Magenta'
  
} catch {
  Write-Host ($global:Error[0] | Out-String).Trim() -ForegroundColor 'Red'
} finally {
  Write-Host "`r`nScript duration:" ((Get-Date) - $script_begin_time).ToString()
  Stop-Transcript
}
return
